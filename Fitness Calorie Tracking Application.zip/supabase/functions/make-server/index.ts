// Re-export the app from the server directory
export { default } from "../server/index.tsx"